//! catraca-server
//!
//! Roda inteiramente na Raspberry Pi. Serve a interface (liquid glass) por
//! HTTP e recebe as credenciais digitadas via WebSocket, digitando-as de
//! volta no sistema atraves de um teclado virtual (uinput). Isso substitui
//! o app Android + ponte ADB/USB antigos: agora o tablet e so uma tela,
//! rodando um WebView apontado pra esse servidor na rede local.

use axum::{
    extract::{
        ws::{Message, WebSocket, WebSocketUpgrade},
        State,
    },
    response::IntoResponse,
    routing::get,
    Router,
};
use serde::{Deserialize, Serialize};
use std::{net::SocketAddr, sync::Arc, time::Duration};
use tokio::sync::Mutex;
use tower_http::{services::ServeDir, trace::TraceLayer};
use tracing_subscriber::EnvFilter;

mod input;
use input::InputSimulator;

const TAMANHO_MAX_CREDENCIAL: usize = 11;
const INTERVALO_PING: Duration = Duration::from_secs(15);

#[derive(Clone)]
struct AppState {
    simulador: Arc<Mutex<Box<dyn InputSimulator>>>,
}

#[derive(Deserialize)]
#[serde(tag = "tipo", rename_all = "snake_case")]
enum MensagemCliente {
    Enviar { codigo: String },
    Pong,
}

#[derive(Serialize)]
#[serde(tag = "tipo", rename_all = "snake_case")]
enum MensagemServidor<'a> {
    Bemvindo,
    Resultado { ok: bool, erro: Option<&'a str> },
    Ping,
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()))
        .init();

    let simulador = input::build_simulator();
    let estado = AppState {
        simulador: Arc::new(Mutex::new(simulador)),
    };

    let porta: u16 = std::env::var("CATRACA_PORT")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(8765);

    let app = Router::new()
        .route("/ws", get(handler_ws))
        .fallback_service(ServeDir::new("static"))
        .layer(TraceLayer::new_for_http())
        .with_state(estado);

    let endereco = SocketAddr::from(([0, 0, 0, 0], porta));
    tracing::info!("catraca-server ouvindo em http://{endereco}");

    let listener = tokio::net::TcpListener::bind(endereco)
        .await
        .expect("nao foi possivel abrir a porta; ela ja esta em uso?");

    axum::serve(listener, app)
        .await
        .expect("servidor encerrou inesperadamente");
}

async fn handler_ws(ws: WebSocketUpgrade, State(estado): State<AppState>) -> impl IntoResponse {
    ws.on_upgrade(move |socket| tratar_socket(socket, estado))
}

async fn tratar_socket(mut socket: WebSocket, estado: AppState) {
    if enviar(&mut socket, &MensagemServidor::Bemvindo).await.is_err() {
        return;
    }

    let mut ticker = tokio::time::interval(INTERVALO_PING);
    ticker.tick().await; // descarta o primeiro tick, que dispara na hora

    loop {
        tokio::select! {
            recebido = socket.recv() => {
                match recebido {
                    Some(Ok(Message::Text(texto))) => {
                        if !processar_texto(&mut socket, &estado, &texto).await {
                            break;
                        }
                    }
                    Some(Ok(Message::Close(_))) | None => break,
                    Some(Err(_)) => break,
                    _ => {}
                }
            }
            _ = ticker.tick() => {
                if enviar(&mut socket, &MensagemServidor::Ping).await.is_err() {
                    break;
                }
            }
        }
    }
}

/// Retorna false quando a conexao deve ser encerrada.
async fn processar_texto(socket: &mut WebSocket, estado: &AppState, texto: &str) -> bool {
    let Ok(msg) = serde_json::from_str::<MensagemCliente>(texto) else {
        return true; // mensagem desconhecida: ignora, nao derruba a conexao
    };

    match msg {
        MensagemCliente::Pong => true,
        MensagemCliente::Enviar { codigo } => {
            let resultado = enviar_credencial(estado, &codigo).await;
            let resposta = match &resultado {
                Ok(()) => MensagemServidor::Resultado { ok: true, erro: None },
                Err(motivo) => MensagemServidor::Resultado {
                    ok: false,
                    erro: Some(motivo.as_str()),
                },
            };
            enviar(socket, &resposta).await.is_ok()
        }
    }
}

async fn enviar_credencial(estado: &AppState, codigo: &str) -> Result<(), String> {
    let valido = !codigo.is_empty()
        && codigo.len() <= TAMANHO_MAX_CREDENCIAL
        && codigo.chars().all(|c| c.is_ascii_digit());

    if !valido {
        return Err("credencial invalida".to_string());
    }

    let mut simulador = estado.simulador.lock().await;
    simulador.type_and_enter(codigo).map_err(|e| e.to_string())
}

async fn enviar(socket: &mut WebSocket, msg: &MensagemServidor<'_>) -> Result<(), axum::Error> {
    let texto = serde_json::to_string(msg).expect("serializacao nunca falha aqui");
    socket.send(Message::Text(texto)).await
}
