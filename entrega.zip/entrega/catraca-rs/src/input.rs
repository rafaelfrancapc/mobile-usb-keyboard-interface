//! Abstrai "digitar a credencial + Enter" de forma que o resto do servidor
//! nao precise saber COMO isso acontece. Hoje existem dois backends:
//!
//! - `uinput`: cria um teclado USB virtual de verdade a nivel de kernel
//!   (/dev/uinput). Funciona independente de X11/Wayland estarem rodando,
//!   e o software de controle de acesso enxerga como um teclado/leitor real.
//!   E o equivalente ao que o pyautogui fazia no bridge antigo, so que sem
//!   depender de foco de janela nem de estar rodando dentro de uma sessao grafica.
//! - `log`: nao digita nada de verdade, so registra no log. Serve pra testar
//!   a interface web num PC comum sem precisar de permissao de /dev/uinput.
//!
//! O modo e escolhido pela variavel de ambiente CATRACA_INPUT_MODE (uinput|log).

use std::error::Error as StdError;

pub type SimResult = Result<(), Box<dyn StdError + Send + Sync>>;

pub trait InputSimulator: Send {
    /// Digita cada digito em sequencia e finaliza com Enter, como um leitor
    /// de codigo de barras / teclado numerico fisico faria.
    fn type_and_enter(&mut self, digits: &str) -> SimResult;
}

/// Escolhe e inicializa o backend de acordo com CATRACA_INPUT_MODE,
/// com fallback seguro para o modo log caso o backend real falhe.
pub fn build_simulator() -> Box<dyn InputSimulator> {
    let mode = std::env::var("CATRACA_INPUT_MODE").unwrap_or_else(|_| default_mode().to_string());

    match mode.as_str() {
        "uinput" => build_uinput(),
        "log" => {
            tracing::warn!("CATRACA_INPUT_MODE=log: nenhuma tecla real sera enviada");
            Box::new(LogSimulator)
        }
        outro => {
            tracing::warn!(%outro, "CATRACA_INPUT_MODE desconhecido, usando modo log");
            Box::new(LogSimulator)
        }
    }
}

#[cfg(feature = "uinput-backend")]
fn default_mode() -> &'static str {
    "uinput"
}

#[cfg(not(feature = "uinput-backend"))]
fn default_mode() -> &'static str {
    "log"
}

#[cfg(feature = "uinput-backend")]
fn build_uinput() -> Box<dyn InputSimulator> {
    match uinput_backend::UinputSimulator::new() {
        Ok(sim) => {
            tracing::info!("backend de entrada: uinput (teclado virtual de kernel)");
            Box::new(sim)
        }
        Err(e) => {
            tracing::error!(
                erro = %e,
                "falha ao criar teclado virtual uinput (confira permissao de /dev/uinput); \
                 caindo para modo log"
            );
            Box::new(LogSimulator)
        }
    }
}

#[cfg(not(feature = "uinput-backend"))]
fn build_uinput() -> Box<dyn InputSimulator> {
    tracing::warn!(
        "binario compilado sem a feature 'uinput-backend'; usando modo log mesmo \
         com CATRACA_INPUT_MODE=uinput"
    );
    Box::new(LogSimulator)
}

/// Backend de desenvolvimento: nao mexe em nada do sistema.
pub struct LogSimulator;

impl InputSimulator for LogSimulator {
    fn type_and_enter(&mut self, digits: &str) -> SimResult {
        tracing::info!(%digits, "[SIMULACAO] digitaria isso + Enter");
        Ok(())
    }
}

#[cfg(feature = "uinput-backend")]
mod uinput_backend {
    use super::{InputSimulator, SimResult};
    use std::{thread, time::Duration};
    use uinput::event::keyboard::Key;

    pub struct UinputSimulator {
        device: uinput::Device,
    }

    impl UinputSimulator {
        pub fn new() -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
            let device = uinput::default()?
                .name("catraca-teclado-virtual")?
                .event(uinput::event::Keyboard::All)?
                .create()?;

            // O kernel/udev leva um instante pra terminar de registrar o
            // dispositivo virtual; sem essa pausa o primeiro clique pode
            // se perder silenciosamente logo apos o processo iniciar.
            thread::sleep(Duration::from_millis(500));

            Ok(Self { device })
        }

        fn key_for_digit(d: char) -> Option<Key> {
            Some(match d {
                '0' => Key::_0,
                '1' => Key::_1,
                '2' => Key::_2,
                '3' => Key::_3,
                '4' => Key::_4,
                '5' => Key::_5,
                '6' => Key::_6,
                '7' => Key::_7,
                '8' => Key::_8,
                '9' => Key::_9,
                _ => return None,
            })
        }
    }

    impl InputSimulator for UinputSimulator {
        fn type_and_enter(&mut self, digits: &str) -> SimResult {
            for c in digits.chars() {
                let key = Self::key_for_digit(c).ok_or("digito invalido no buffer")?;
                self.device.click(&key)?;
                self.device.synchronize()?;
                // pequeno intervalo entre teclas: alguns leitores/softwares de
                // controle de acesso perdem eventos se chegarem rapido demais
                thread::sleep(Duration::from_millis(12));
            }

            self.device.click(&Key::Enter)?;
            self.device.synchronize()?;

            Ok(())
        }
    }
}
