(() => {
  "use strict";

  const MAX_DIGITOS = 11;
  const DELAY_LONG_PRESS_MS = 500;
  const RECONEXAO_MIN_MS = 1000;
  const RECONEXAO_MAX_MS = 8000;
  const TENTATIVAS_ATE_SEM_CONEXAO = 4;

  const els = {
    readout: document.getElementById("readout"),
    readoutText: document.getElementById("readoutText"),
    status: document.getElementById("status"),
    statusText: document.getElementById("statusText"),
    keypad: document.getElementById("keypad"),
    btnDel: document.getElementById("btnDel"),
    btnEnter: document.getElementById("btnEnter"),
  };

  if (new URLSearchParams(location.search).get("lite") === "1") {
    document.body.classList.add("lite");
  }

  // ---------------------------------------------------------------------
  // Feedback tatil e sonoro (substitui AudioManager/Vibrator do app antigo)
  // ---------------------------------------------------------------------

  let audioCtx = null;
  function ctx() {
    if (!audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AC();
    }
    return audioCtx;
  }

  function bipe(freq, duracaoMs, volume = 0.05) {
    try {
      const c = ctx();
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.value = volume;
      osc.connect(gain).connect(c.destination);
      osc.start();
      gain.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + duracaoMs / 1000);
      osc.stop(c.currentTime + duracaoMs / 1000 + 0.02);
    } catch (_) { /* audio indisponivel, ignora */ }
  }

  function vibrar(ms) {
    if (navigator.vibrate) navigator.vibrate(ms);
  }

  function feedbackDigito() { vibrar(15); bipe(880, 40); }
  function feedbackDelete() { vibrar(15); bipe(320, 45); }
  function feedbackLimparTudo() { vibrar(45); bipe(220, 90); }
  function feedbackEnterOk() { vibrar(25); bipe(660, 90, 0.06); }
  function feedbackEnterErro() { vibrar([20, 40, 20]); bipe(180, 160, 0.07); }

  // ---------------------------------------------------------------------
  // Buffer da credencial
  // ---------------------------------------------------------------------

  let buffer = "";

  function atualizarDisplay() {
    els.readoutText.textContent = buffer;
    els.readout.classList.toggle("has-value", buffer.length > 0);
  }

  function flash(tipo) {
    const classe = tipo === "ok" ? "flash-ok" : "flash-erro";
    els.readout.classList.add(classe);
    setTimeout(() => els.readout.classList.remove(classe), 260);
  }

  function adicionarDigito(d) {
    if (buffer.length >= MAX_DIGITOS) return;
    buffer += d;
    atualizarDisplay();
    feedbackDigito();
  }

  function apagarUltimo() {
    if (!buffer.length) return;
    buffer = buffer.slice(0, -1);
    atualizarDisplay();
    feedbackDelete();
  }

  function limparTudo() {
    if (!buffer.length) return;
    buffer = "";
    atualizarDisplay();
    feedbackLimparTudo();
  }

  function confirmar() {
    if (!buffer.length) return;
    const enviado = enviarCredencial(buffer);
    if (!enviado) {
      flash("erro");
      feedbackEnterErro();
    }
  }

  // ---------------------------------------------------------------------
  // Botoes numericos
  // ---------------------------------------------------------------------

  els.keypad.querySelectorAll(".key[data-digit]").forEach((btn) => {
    btn.addEventListener("click", () => adicionarDigito(btn.dataset.digit));
  });

  // apagar: toque curto apaga 1, segurar apaga tudo (igual ao app original)
  let delTimer = null;
  let delSegurou = false;

  els.btnDel.addEventListener("pointerdown", () => {
    delSegurou = false;
    delTimer = setTimeout(() => {
      delSegurou = true;
      limparTudo();
    }, DELAY_LONG_PRESS_MS);
  });

  ["pointerup", "pointerleave", "pointercancel"].forEach((ev) => {
    els.btnDel.addEventListener(ev, () => {
      clearTimeout(delTimer);
      if (ev === "pointerup" && !delSegurou) apagarUltimo();
    });
  });

  els.btnEnter.addEventListener("click", confirmar);

  // ---------------------------------------------------------------------
  // WebSocket com reconexao automatica e heartbeat
  // ---------------------------------------------------------------------

  let ws = null;
  let tentativas = 0;
  let pendente = null; // { resolve } do envio em andamento

  function definirStatus(estado, texto) {
    els.status.dataset.state = estado;
    els.statusText.textContent = texto;
  }

  function conectar() {
    const protocolo = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${protocolo}//${location.host}/ws`);

    ws.addEventListener("open", () => {
      tentativas = 0;
      definirStatus("conectado", "conectado");
    });

    ws.addEventListener("message", (evento) => {
      let msg;
      try { msg = JSON.parse(evento.data); } catch (_) { return; }

      switch (msg.tipo) {
        case "bemvindo":
          definirStatus("conectado", "conectado");
          break;
        case "ping":
          ws.send(JSON.stringify({ tipo: "pong" }));
          break;
        case "resultado":
          if (pendente) {
            pendente = null;
            if (msg.ok) {
              buffer = "";
              atualizarDisplay();
              flash("ok");
              feedbackEnterOk();
            } else {
              flash("erro");
              feedbackEnterErro();
            }
          }
          break;
      }
    });

    ws.addEventListener("close", agendarReconexao);
    ws.addEventListener("error", () => ws.close());
  }

  function agendarReconexao() {
    tentativas += 1;
    definirStatus(
      tentativas > TENTATIVAS_ATE_SEM_CONEXAO ? "sem-conexao" : "reconectando",
      tentativas > TENTATIVAS_ATE_SEM_CONEXAO ? "sem conexão" : "reconectando…"
    );
    const espera = Math.min(RECONEXAO_MIN_MS * 2 ** (tentativas - 1), RECONEXAO_MAX_MS);
    setTimeout(conectar, espera);
  }

  function enviarCredencial(codigo) {
    if (!ws || ws.readyState !== WebSocket.OPEN) return false;
    pendente = true;
    ws.send(JSON.stringify({ tipo: "enviar", codigo }));
    return true;
  }

  atualizarDisplay();
  conectar();
})();
