package com.franc.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * O app deixou de ser o terminal em si: agora ele so exibe, em tela cheia,
 * a interface liquid glass servida pelo catraca-server rodando na Raspberry
 * Pi (HTTP na rede local). Toda a logica de buffer, feedback e injecao de
 * teclado mudou pro lado do servidor; aqui so sobra "abrir a pagina e nao
 * deixar o usuario sair dela".
 */
class MainActivity : AppCompatActivity() {

    companion object {
        // Endereco padrao da Raspberry Pi, usado so na primeira execucao ou
        // se o usuario nunca configurou nada pelo menu oculto.
        private const val DEFAULT_SERVER_URL = "http://192.168.42.222:8765/"

        private const val PREFS_NAME = "catraca_config"
        private const val PREF_SERVER_URL = "server_url"

        private const val RETRY_INICIAL_MS = 2000L
        private const val RETRY_MAXIMO_MS = 15000L
    }

    private lateinit var webView: WebView
    private lateinit var overlayStatus: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private var serverUrl: String = DEFAULT_SERVER_URL

    private val handler = Handler(Looper.getMainLooper())
    private var retryDelayMs = RETRY_INICIAL_MS
    private var retryRunnable: Runnable? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        serverUrl = prefs.getString(PREF_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL

        webView = findViewById(R.id.webView)
        overlayStatus = findViewById(R.id.tvStatusOverlay)

        configurarWebView()
        configurarMenuOcultoDeConfiguracao()

        carregarTerminal()
    }

    override fun onResume() {
        super.onResume()
        aplicarImersao()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // sem isso o modo imersivo volta a aparecer sempre que o usuario
        // arrasta a barra de notificacoes e solta de novo
        if (hasFocus) aplicarImersao()
    }

    override fun onDestroy() {
        cancelarRetryPendente()
        webView.destroy()
        super.onDestroy()
    }

    // Terminal de parede: o botao voltar do sistema nao deve derrubar o app.
    // Comente este override se quiser poder sair normalmente durante testes.
    override fun onBackPressed() {
        // intencionalmente vazio
    }

    // ---------------------------------------------------------------------
    // Modo quiosque / tela cheia
    // ---------------------------------------------------------------------

    private fun aplicarImersao() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    // ---------------------------------------------------------------------
    // WebView
    // ---------------------------------------------------------------------

    private fun configurarWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            // servidor local costuma ser so http; sem isso o WebView bloqueia
            // a pagina em builds com targetSdk mais recente
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            textZoom = 100
        }

        // impede o menu de "copiar / compartilhar link" ao segurar o dedo
        // em algum elemento da pagina
        webView.setOnLongClickListener { true }
        webView.isHapticFeedbackEnabled = true

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                retryDelayMs = RETRY_INICIAL_MS
                cancelarRetryPendente()
                overlayStatus.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame != false) {
                    mostrarErroEAgendarRetry()
                }
            }
        }
    }

    private fun carregarTerminal() {
        overlayStatus.visibility = View.VISIBLE
        overlayStatus.text = "Conectando ao terminal…"
        webView.loadUrl(serverUrl)
    }

    private fun mostrarErroEAgendarRetry() {
        overlayStatus.visibility = View.VISIBLE
        overlayStatus.text = "Sem conexão com $serverUrl\nTentando de novo…"

        cancelarRetryPendente()
        val runnable = Runnable {
            webView.loadUrl(serverUrl)
            retryDelayMs = (retryDelayMs * 2).coerceAtMost(RETRY_MAXIMO_MS)
        }
        retryRunnable = runnable
        handler.postDelayed(runnable, retryDelayMs)
    }

    private fun cancelarRetryPendente() {
        retryRunnable?.let { handler.removeCallbacks(it) }
        retryRunnable = null
    }

    // ---------------------------------------------------------------------
    // Menu oculto: alterar o endereco do servidor
    // (long-press na area transparente no canto superior direito da tela)
    // ---------------------------------------------------------------------

    private fun configurarMenuOcultoDeConfiguracao() {
        findViewById<View>(R.id.hiddenConfigHotspot).setOnLongClickListener {
            abrirMenuDeConfiguracao()
            true
        }
    }

    private fun abrirMenuDeConfiguracao() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(serverUrl)
            setSelection(text.length)
        }

        val paddingPx = (20 * resources.displayMetrics.density).toInt()
        val container = FrameLayout(this).apply {
            setPadding(paddingPx, paddingPx, paddingPx, 0)
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Configuração de rede")
            .setMessage("Endereço do terminal (ex: http://192.168.42.222:8765/):")
            .setView(container)
            .setPositiveButton("Salvar") { _, _ ->
                var novoUrl = input.text.toString().trim()
                if (novoUrl.isNotEmpty() && !novoUrl.startsWith("http")) {
                    novoUrl = "http://$novoUrl"
                }
                if (novoUrl.isNotEmpty() && novoUrl != serverUrl) {
                    serverUrl = novoUrl
                    prefs.edit().putString(PREF_SERVER_URL, novoUrl).apply()
                    Toast.makeText(this, "Endereço salvo: $novoUrl", Toast.LENGTH_SHORT).show()
                    retryDelayMs = RETRY_INICIAL_MS
                    carregarTerminal()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
