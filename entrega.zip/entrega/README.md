# Catraca — terminal de credencial (Rust na Raspberry Pi + WebView no tablet)

## O que mudou

**Antes:** o tablet rodava um app Android nativo com o teclado numérico
(`MainActivity.kt`), conectava via cabo USB + `adb forward` a um daemon
Python (`rpi_adb_bridge.py`) que ficava na Raspberry Pi (ou no PC), e esse
daemon usava `pyautogui` pra digitar a credencial na tela. O tethering USB
RNDIS era o elo fraco — bug de driver no kernel, conexão caindo.

**Agora:** a Raspberry Pi passa a ser o servidor de tudo. Ela serve uma
página web (interface liquid glass, no lugar dos botões nativos) e recebe as
credenciais digitadas por WebSocket. Em vez de `pyautogui`, ela mesma injeta
as teclas usando `/dev/uinput` — um teclado USB virtual em nível de kernel,
que funciona independente de sessão gráfica. O tablet só precisa estar na
mesma rede local (Wi-Fi ou Ethernet, não precisa mais ser USB) e abrir essa
página dentro de um WebView.

```
┌─────────────┐   Wi-Fi/Ethernet (rede local)   ┌───────────────────────────┐
│   Tablet     │ ───────────────────────────────▶│      Raspberry Pi         │
│  (WebView)   │ ◀─────── WebSocket /ws ──────────│  catraca-server (Rust)    │
└─────────────┘                                  │  → digita via /dev/uinput │
                                                   │  → app local le a tecla   │
                                                   └───────────────────────────┘
```

## Estrutura desta entrega

```
catraca-rs/                 servidor Rust (Axum) + interface web
  Cargo.toml
  src/main.rs                rotas HTTP/WS
  src/input.rs                injeção de teclado (uinput / log)
  static/index.html           markup da interface
  static/style.css            liquid glass (paleta original: sage/teal/verde/vermelho)
  static/app.js                buffer, feedback tátil/sonoro, reconexão

catraca-webview-android/    app Android mínimo (substitui o MainActivity antigo)
  MainActivity.kt             WebView em kiosk, retry automático, menu oculto de IP
  AndroidManifest.xml
  activity_main.xml
```

O `AndroidManifest.xml`, `bg_botao_*.xml`, `bg_display_moldura.xml` e os
`ic_launcher*.xml` que você já tinha continuam relevantes só para o ícone do
app (`ic_launcher*`); os drawables de botão (`bg_botao_*`, `bg_display_moldura`)
não são mais usados, já que os botões agora são HTML/CSS servidos pela Pi —
pode apagá-los do projeto Android.

---

## 1. Raspberry Pi — servidor

### 1.1 Instalar Rust e dependências de build

```bash
curl https://sh.rustup.rs -sSf | sh -s -- -y
source "$HOME/.cargo/env"
sudo apt update
sudo apt install -y libudev-dev pkg-config
```

### 1.2 Copiar o projeto e compilar

```bash
# copie a pasta catraca-rs/ pra Pi (scp, git, pendrive, o que for)
cd catraca-rs
cargo build --release
```

O binário fica em `target/release/catraca-server`. Compilar direto na Pi
evita todo o trabalho de cross-compilation — é mais lento que num PC, mas
como é só um `cargo build` ocasional, não costuma valer a complexidade extra.
Se preferir compilar no seu notebook e mandar só o binário, dá pra usar a
ferramenta `cross` (Docker) com o target certo (`aarch64-unknown-linux-gnu`
pra Pi 64-bit ou `armv7-unknown-linux-gnueabihf` pra 32-bit).

### 1.3 Permissão pra criar o teclado virtual (uinput)

Por padrão só root acessa `/dev/uinput`. Pra rodar o serviço com um usuário
normal (recomendado — evitar rodar como root sempre que der):

```bash
sudo tee /etc/udev/rules.d/99-uinput.rules >/dev/null <<'EOF'
KERNEL=="uinput", GROUP="input", MODE="0660"
EOF

echo "uinput" | sudo tee /etc/modules-load.d/uinput.conf
sudo modprobe uinput
sudo usermod -aG input "$USER"
# depois disso, faça logout/login (ou reinicie) pra o grupo valer
```

### 1.4 Testar manualmente antes de virar serviço

```bash
cd catraca-rs
CATRACA_INPUT_MODE=log ./target/release/catraca-server
# abra http://<ip-da-pi>:8765/ num navegador e teste o teclado —
# nesse modo ele só *loga* o que digitaria, não mexe em nada de verdade

CATRACA_INPUT_MODE=uinput ./target/release/catraca-server
# agora ele digita de verdade: deixe o foco em algum campo de texto/terminal
# e confira que os dígitos + Enter aparecem lá quando você usa o teclado web
```

### 1.5 Deixar rodando sempre (systemd)

```bash
sudo tee /etc/systemd/system/catraca.service >/dev/null <<EOF
[Unit]
Description=Catraca - terminal de credencial
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=$(pwd)
ExecStart=$(pwd)/target/release/catraca-server
Environment=CATRACA_PORT=8765
Environment=CATRACA_INPUT_MODE=uinput
Restart=always
RestartSec=2
User=$USER

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now catraca.service
journalctl -u catraca.service -f   # acompanhar os logs
```

### 1.6 Achar a Pi na rede sem decorar IP

Se o Avahi/mDNS estiver ativo (geralmente já vem no Raspberry Pi OS), dá pra
acessar por `http://raspberrypi.local:8765/` (ou o hostname que você definir
no `raspi-config`), em vez de um IP fixo — assim o endereço configurado no
tablet não quebra se o IP mudar via DHCP.

---

## 2. Tablet — app WebView

O `MainActivity.kt` novo não tem mais lógica de teclado nem socket próprio:
ele só abre, em tela cheia e sem barra de sistema, a URL do terminal servido
pela Pi, com reconexão automática caso a página não carregue.

- **Configurar o endereço:** segure o dedo por ~0,5s no canto superior
  direito da tela (área invisível, do mesmo jeito que o app antigo usava
  long-press no rótulo do display) — abre um diálogo pra digitar
  `http://raspberrypi.local:8765/` ou o IP da Pi.
- **Botão voltar:** fica bloqueado de propósito (é um terminal de parede).
  Se quiser poder sair durante os testes, comente o `onBackPressed()`
  vazio em `MainActivity.kt`.
- **HTTP sem TLS:** como é tudo rede local, o manifest já libera
  `usesCleartextTraffic`. Se um dia a Pi passar a servir HTTPS, isso pode
  ser removido.

Compile e instale como o projeto Android já era compilado antes (Android
Studio ou `./gradlew installDebug`), reaproveitando o resto do projeto
(gradle files, ícones) que você já tinha.

---

## 3. Sobre o "liquid glass"

A paleta manteve as cores que você já tinha nos drawables originais —
`#18332F` (teal profundo), `#5E7461` (sage do display), `#DA291C`
(delete) e `#43B02A` (enter) — só que reinterpretadas como vidro fosco
(`backdrop-filter: blur`) sobre um fundo escuro com dois brilhos suaves,
e um sheen diagonal nos botões que se intensifica ao pressionar (o efeito
"líquido" — ver `.key::before` em `static/style.css`).

Como o tablet pode ser hardware mais fraco, tem uma válvula de escape: abrir
a página com `?lite=1` (ex: `http://raspberrypi.local:8765/?lite=1`) remove
os `backdrop-filter` (o item mais caro pra GPU) e usa cores sólidas mais
opacas no lugar, mantendo a mesma paleta e layout.

---

## 4. Segurança — vale ler antes de colocar em produção

Hoje o `/ws` não tem autenticação: qualquer dispositivo na mesma rede local
consegue abrir a página e mandar credenciais, ou até se conectar direto no
WebSocket sem passar pela interface. Numa rede doméstica/IFF isso pode ser
aceitável, mas dá pra reforçar depois com pouco esforço:

- restringir a porta 8765 por firewall (`ufw`/`iptables`) só ao IP do tablet;
- exigir um token compartilhado na conexão WebSocket (`?token=...` checado
  no `handler_ws`);
- colocar a Pi numa VLAN separada dos demais dispositivos.

Nenhuma dessas está implementada nesta entrega pra manter o escopo focado no
que você pediu (mover tudo pra Rust + WebView), mas é o próximo passo natural
se esse terminal for ficar exposto além de uma rede totalmente confiável.
